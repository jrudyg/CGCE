## v0.1 (initial)
- Scaffold created
- Instructions populated
- Schemas added
- Tools + agent stubs implemented (stdlib only)
- Tests + fixtures added
- Make targets for POSIX + Windows
