Geek+ announces new parcel AMR deployment
Integration note: focuses on sortation to parcel injection. Reference client not specified. Source: fixture.
